<?php
/**
*
* @package Board3 Portal v2 - Plugin for ezStats3
* @copyright (c) Board3 Group ( www.board3.de )
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

if (!defined('IN_PHPBB')) exit;


/**
* @package ezstats3_wowp
*/
class portal_ezstats3_wowp_module {
	public $columns = 31;
	public $name = 'PORTAL_EZSTATS3_WOWP';
	public $image_src = 'portal_ezstats3_wowp.png';
	public $language = 'portal_ezstats3_wowp_module';
	public $custom_acp_tpl = '';
	public $hide_name = false;
	
	public function get_template_center($module_id) {
		global $config, $template;
		
		$url = $config['board3_ezstats3_wowp_url_' . $module_id];
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
		$output = curl_exec($ch);
		curl_close($ch);
		
		$template->assign_vars(array(
			'LEADERBOARD'			=> $output
		));
		
		return 'ezstats3_wowp_center.html';
	}

	public function get_template_side($module_id) {
		global $config, $template;
		
		$url = $config['board3_ezstats3_wowp_url_' . $module_id];
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
		$output = curl_exec($ch);
		curl_close($ch);
		
		$template->assign_vars(array(
			'LEADERBOARD'			=> $output
		));
		
		return 'ezstats3_wowp_side.html';
	}
	
	function get_template_acp($module_id) {
		return array(
			'title'    => 'ACP_PORTAL_EZSTATS3_WOWP_SETTINGS',
			'vars'    => array(
				'legend1' => 'ACP_PORTAL_EZSTATS3_WOWP_SETTINGS',
				'board3_ezstats_url_' . $module_id => array(
					'lang' => 'PORTAL_EZSTATS3_WOWP_URL',
					'validate' => 'string',
					'type' => 'text:20:999',
					'explain' => true
				),
			)
		);
	}  

	/**
	* API functions
	*/
	
	public function install($module_id) {
		return false;
	}

	public function uninstall($module_id) {
		return false;
	}
}
