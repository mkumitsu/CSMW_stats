<?php
/*
+------------------------------------------------------------------------------+
|     YourFirstPlugin - a plugin skeleton by nlstart
|
|	Plugin Support Site: e107.webstartinternet.com
|
|	For the e107 website system visit http://e107.org
|
|	Released under the terms and conditions of the
|	GNU General Public License (http://gnu.org).
+------------------------------------------------------------------------------+
*/
// If e107 is not running we won't run this plugin program
if( ! defined('e107_INIT')){ exit(); }

// Use this folder during install
$eplug_folder = "ezstats3_wowp";

// Get language file (assume that the English language file is always present)
include_lan(e_PLUGIN.'yourfirstplugin/languages/'.e_LANGUAGE.'.php');

// To keep plugin name multilangual: store the constant name in the plugin table
// Plugin name is multi-language (from included language file)
// Otherwise for a fixed language term use the language constant name without the quotes
$eplug_name = 'ezstats3_wowp';
$eplug_version = "";
$eplug_author = "ezzemm";
$eplug_url = "http://www.ezstats.org";
$eplug_email = "";
$eplug_description = "ezStats 3 for World of Warplanes";
$eplug_compatible = "e107v0.7+";
$eplug_compliant = TRUE; // indicator if plugin is XHTML compliant, shows icon
$eplug_readme = "";

$eplug_menu_name = "ezstats3_wowp";
$eplug_conffile = "";
$eplug_icon = $eplug_folder."/images/logo_32.png";
$eplug_icon_small = $eplug_folder."/images/logo_16.png";
$eplug_caption = "";

// List of preferences ---------------------------------------------------------
// this stores a default value(s) in the preferences. 0 = Off , 1= On
// Preferences are saved with plugin folder name as prefix to make preferences unique and recognisable
$eplug_prefs = array(
	$eplug_folder."_name" => "ezstats3_wowp",
    $eplug_folder."_image_path" => "images/",
    $eplug_folder."_test_01" => "Test field 01",
    $eplug_folder."_test_02" => "Test field 02",
    $eplug_folder."_test_03" => "Test field 03",
    $eplug_folder."_test_04" => "Test field 04",
    $eplug_folder."_test_integer" => 1000
);

// List of table names ---------------------------------------------------------
$eplug_table_names = array();

// List of sql requests to create tables ---------------------------------------
// MPREFIX must be used because database prefix can be customized instead of default e107_
$eplug_tables = array();

// Create a link in main menu (yes=TRUE, no=FALSE) ---------------------------
$eplug_link = TRUE;

// To keep link multilangual: store the constant name in the links table
$eplug_link_name = 'ezstats3_wowp';

?>