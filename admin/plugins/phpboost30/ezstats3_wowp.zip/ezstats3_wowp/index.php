<?php header('location: ./ezstats3_wowp.php'); ?>
