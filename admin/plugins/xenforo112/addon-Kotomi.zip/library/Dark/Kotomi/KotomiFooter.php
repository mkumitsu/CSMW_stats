<?php
  $kotomi_fc->runKotomi(ob_get_clean());
