<?php
// ClanSphere 2009 - www.clansphere.net
// $Id: access.php 3009 2009-05-03 14:57:11Z hajo $

$axx_file['list'] = 1;
$axx_file['center'] = 1;
$axx_file['manage'] = 4;