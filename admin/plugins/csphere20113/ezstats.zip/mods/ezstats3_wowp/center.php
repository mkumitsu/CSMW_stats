<?php
// ClanSphere 2009 - www.clansphere.net

$data = array();
$data['ezstats3_wowp']['link'] = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?mod=ezstats3_wowp';
$data['ezstats3_wowp']['headline'] = "ezStats3 - Leaderboard for World of Warplanes";
$data['ezstats3_wowp']['content'] = 'Open ezStats with this link: <a href="'.$data['ezstats3_wowp']['link'].'">'.$data['ezstats3_wowp']['link'].'</a>';

echo cs_subtemplate(__FILE__, $data, 'ezstats3_wowp');