<?php
// ClanSphere 2009 - www.clansphere.net
// $Id: info.php 3009 2009-05-03 14:57:11Z hajo $


$mod_info['name']    = "ezstats3_wowp";
$mod_info['version']  = $cs_main['version_name'];
$mod_info['released']  = $cs_main['version_date'];
$mod_info['creator']  = 'ezzemm';
$mod_info['team']    = 'http://www.ezstats.org';
$mod_info['url']    = 'http://www.ezstats.org';
$mod_info['text']    = "ezStats3 - Leaderboard for World of Warplanes";
$mod_info['icon']     = 'misc';
$mod_info['show']     = array('clansphere/admin' => 4, 'users/settings' => 1);
$mod_info['categories']  = TRUE;
$mod_info['comments']  = TRUE;
$mod_info['protected']  = FALSE;