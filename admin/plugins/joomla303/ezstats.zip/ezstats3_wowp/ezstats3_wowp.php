<?php
defined('_JEXEC') or die('Direct access denied');
jimport('joomla.plugin.plugin');

class plgContentezstats3_wowp extends JPlugin
{

    // Joomla 1.5
    /*public*/ function onPrepareContent(&$article, &$params, $limitstart)
    {
        $this->_worker($article, $params);
    }

    // Joomla 2.5
    /*public*/ function onContentPrepare($context, &$article, &$params, $limitstart)
    {
        $this->_worker($article, $params);
    }

    /*protected*/ function _worker(&$article, &$params)
    {
        $ph = $this->params->get("placeholder");
        if (strpos($article->text, $ph) !== false) {
            // Found our tag. Let's go to work...

            // The URL is part of the cache key, so it must be correctly
            // calculated before we invoke the cache.
            $url = $this->params->get("url");
            if (substr($url, -1, 1) != "/") {
                $url = $url."/";
            }
            if (substr($url, 0, 2) == "//") {
                $cu = JURI::getInstance();
                $url = $cu->getScheme().':'.$url;
            } else {
                if (substr($url, 0, 7) != "http://") $url = "http://".$url;
            }

            $cache =& JFactory::getCache('ezstats3_bf4');
            $stats = $cache->get(array('plgContentezstats3_wowp', '_fetch_ezstats'), array($url));
            $article->text = str_replace($ph,
                (($stats === false) ? 'Could not fetch ezStats3 data!' : $stats), $article->text);
        }
    }

    /** MUST be public static, because JCache invokes this as callback */
    /*public*/ static function _fetch_ezstats($url)
    {
        $ch = curl_init($url);
        if ($ch === false) {
            return false;
        }
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); // Allow self signed certificates
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); // Allow certsubject/hostname mismatch
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
        $output = curl_exec($ch);
        curl_close($ch);
        return $output;
    }
}
