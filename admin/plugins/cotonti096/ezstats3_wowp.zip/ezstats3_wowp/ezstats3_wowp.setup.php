<?php
/* ====================
[BEGIN_COT_EXT]
Name=ezstats3_wowp
Description=Includes ezStats 3 for World of Warplanes
Version=1
Date=2013-03-21
Author=ezzemm
Copyright=
Notes=
Auth_guests=R
Lock_guests=A
Auth_members=R
Lock_members=
[END_COT_EXT]
==================== */
?>